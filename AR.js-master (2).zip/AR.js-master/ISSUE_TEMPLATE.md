<!-- Please, DO NOT OPEN NEW ISSUES HERE: AR.js IS NOW AVAILABLE AT: https://github.com/AR-js-org/AR.js -->

**⚠️ AR.js repository has been moved, please check it out at: https://github.com/AR-js-org/AR.js ⚠️**
