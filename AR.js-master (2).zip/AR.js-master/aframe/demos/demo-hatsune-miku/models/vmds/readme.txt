readme_wavefile.txt: readme of wavefile dance motion data
readme_wavefile_camera: readme of the original wavefile camera motion data

wavefile_camera.vmd is camera motion data I've customized from this data

http://www.nicovideo.jp/watch/sm19168559

Note that the original author allows customized data file redistribution
but doesn't allow the original file redistribution.

And wavefile_camera.vmd inherits the policy of the original file.
- You must not use the file for porn.
- You must not cause any troubles to anyone especially other copyright holders,
  (WAVEFILE music composer, WAVEFILE dance motion author, and so on)

                                       by Takahiro
