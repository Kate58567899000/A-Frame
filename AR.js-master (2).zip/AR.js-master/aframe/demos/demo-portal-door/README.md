# TODO support live scene
- i can put a live scene in there
- cache material on sphere when outside portal - thus real scene is hidden
- it can work for sphere 360 it has nothing special
- good thus ALL the content is handled outside

---
- thus it can be a way to visual VR in AR
- good because to put a video in tango is too slow
- TODO make the source a image or a video
- make it a live scene too ?
- in outsidePortal + live-scene => add a cache sphere

-------------------
- DONE a actual entity
- DONE support movie url too
- DONE do that in a THREEx - add it to webar-playground
