- https://www.mapbox.com/mapbox-gl-js/example/3d-buildings/

https://blog.mapbox.com/global-elevation-data-6689f1d0ba65
